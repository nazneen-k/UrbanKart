package com.app.dto;

import java.time.LocalDate;

public class PaymentDTO {
	private String cardNumber;
	private LocalDate expirayDate;
	private String ccv;
	private String holderName;
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public LocalDate getExpirayDate() {
		return expirayDate;
	}
	public void setExpirayDate(LocalDate expirayDate) {
		this.expirayDate = expirayDate;
	}
	public String getCcv() {
		return ccv;
	}
	public void setCcv(String ccv) {
		this.ccv = ccv;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public PaymentDTO(String cardNumber, LocalDate expirayDate, String ccv, String holderName) {
		super();
		this.cardNumber = cardNumber;
		this.expirayDate = expirayDate;
		this.ccv = ccv;
		this.holderName = holderName;
	}
	@Override
	public String toString() {
		return "PaymentDTO [cardNumber=" + cardNumber + ", expirayDate=" + expirayDate + ", ccv=" + ccv
				+ ", holderName=" + holderName + "]";
	}
	

}

