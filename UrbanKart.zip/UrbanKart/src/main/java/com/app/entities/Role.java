package com.app.entities;

public enum Role {
	CUSTOMER,ADMIN

}
