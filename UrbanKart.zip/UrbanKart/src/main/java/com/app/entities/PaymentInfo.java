package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "payment_info")
public class PaymentInfo {
	@Id
	@Column
	private Long orderId;
	@Column
	private String cardNumber;
	@Column
	private LocalDate expirayDate;
	@Column
	private String ccv;
	@Column
	private String holderName;
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public LocalDate getExpirayDate() {
		return expirayDate;
	}
	public void setExpirayDate(LocalDate expirayDate) {
		this.expirayDate = expirayDate;
	}
	public String getCcv() {
		return ccv;
	}
	public void setCcv(String ccv) {
		this.ccv = ccv;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public PaymentInfo(Long orderId, String cardNumber, LocalDate expirayDate, String ccv, String holderName) {
		super();
		this.orderId = orderId;
		this.cardNumber = cardNumber;
		this.expirayDate = expirayDate;
		this.ccv = ccv;
		this.holderName = holderName;
	}
	
	public PaymentInfo() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "PaymentInfo [orderId=" + orderId + ", cardNumber=" + cardNumber + ", expirayDate=" + expirayDate
				+ ", ccv=" + ccv + ", holderName=" + holderName + "]";
	}

}
